/*
CONTENTS
	1. Basic Info
	2. The Content
		2.1. Posts
		2.2. Messages
	3. Creating Insertable HTML
		3.1. Post Page
		3.2. Archive List
		3.3. Recent Post List
		3.4. Tag Index
	4. Inserting HTML Into Pages

INSTRUCTIONS
	To add a new post, copy this object literal into the top of postsArray in section 2.1:
		{
			path: "filename",
			title: "post title/heading",
			tags: ["tag 1", "tag 2", "etc."]
			projects: ["project"]
		},
	Replace 'filename' with the name of the file (not the file extension, though).
	Replace 'post title/heading' with a human-readable post title.
	Replace 'tag 1', 'tag 2' etc. with tags (if no tags, leave the array empty).

	Safe characters to use in titles: anything except ordinary (not left/right) double-quotes.
	To use ordinary double-quotes, put a backslash before each one.
	(e.g. title: "How to \"use\" double-quotes in titles")

	Safe characters to use in tags:
		letters (upper- or lowercase)
		numbers
		? / : @ - . _ ~ ! $ & ' ( ) * + , ; = (question mark, slash, colon, at sign, hyphen-minus, period, underscore, tilde, exclamation mark, dollar, ampersand, apostrophe, left parenthesis, right parenthesis, asterisk, plus, comma, semicolon, equals)
		spaces (will be replaced by hyphens in tag urls)

	To add a new message, add it to messagesArray in section 2.2. The order doesn't matter.
*/



/* ==================
	1. BASIC INFO
================== */

const blogName = "Splendide Mendax";
const recentPostsCutoff = 5; // set the number of most-recent posts displayed on the index page
const headerMessageOn = true; // switch header messages on (true) or off (false)

const footerLinks = [ // set links in the footer
	'<a href="https://splendidemendax.tumblr.com/">tumblr</a>',
	'<a href="https://archiveofourown.org/users/splendide_mendax">ao3</a>'
];



/* ===================
	2. THE CONTENT
=================== */

/* ---------------
	2.1. POSTS
--------------- */

const postsArray = [
	{
		path: "2024-03-20_the_gender_of_gravity",
		title: "the gender of gravity",
		tags: ["auth:sophocles", "topic:trek", "topic:trauma",  "auth:herman, judith", "type:essay", "lang:greek"],
		projects: ["experiments in trauma studies"]
	},
	{
		path: "2024-03-15_electra_and_trauma_and_recovery",
		title: "electra and trauma and recovery",
		tags: ["type:art", "auth:sophocles", "topic:trauma", "auth:herman, judith", "auth:carson, anne", "lang:greek"],
		projects: ["experiments in trauma studies"]
	},
	{
		path: "2024-03-10_trauma_and_narrative_in_DS9_and_the_Aeneid",
		title: "trauma and narrative in DS9 and the Aeneid",
		tags: ["auth:vergil", "topic:trek", "topic:trauma", "auth:shay, jonathan", "auth:herman, judith", "type:essay", "lang:latin"],
		projects: ["experiments in trauma studies"]
	},
	{
		path: "2024-01-24_worship_and_slaughter",
		title: "worship and slaughter",
		tags: ["lang:latin"],
		projects: []
	},
	{
		path: "2024-01-20_high_frequency_vocabulary",
		title: "high frequency vocabulary",
		tags: ["lang:latin", "lang:greek"],
		projects: []
	},
	{
		path: "2024-01-09_the_world's_tiniest_web_weaving",
		title: "the world's tiniest web weaving",
		tags: ["auth:homer", "genre:fado"],
		projects: []
	},
	{
		path: "2023-12-28_agrippina_the_hotter",
		title: "agrippina the hotter",
		tags: ["auth:tacitus"],
		projects: []
	},
	{
		path: "2023-12-27_tacitus_annales_13.1–3",
		title: "tacitus annales 13.1–3",
		tags: ["auth:tacitus"],
		projects: []
	},
	{
		path: "2023-12-15_the_heroides_and_authenticity",
		title: "the heroides and authenticity",
		tags: ["auth:ovid", "type:response"],
		projects: []
	},
	{
		path: "2023-11-17_achilles_in_vietnam",
		title: "achilles in vietnam",
		tags: ["auth:shay, jonathan", "topic:trauma", "type:response"],
		projects: ["experiments in trauma studies"]
	},
	{
		path: "2023-10-24_humor_and_humanity",
		title: "humor and humanity",
		tags: ["auth:ovid", "topic:queerness", "type:response"],
		projects: []
	},
	{
		path: "2023-09-08_ur-fascism_and_in_a_mirror_darkly",
		title: "ur-fascism and \"in a mirror, darkly\"",
		tags: ["topic:trek", "auth:eco, umberto"],
		projects: []
	},
	{
		path: "2023-09-08_painter_of_bologna_kylix",
		title: "painter of bologna kylix",
		tags: ["type:art"],
		projects: []
	},
	{
		path: "2023-09-05_cave_canem",
		title: "cave canem",
		tags: ["type:art"],
		projects: []
	},
	{
		path: "2023-08-02_sophocles:_elektra",
		title: "sophocles: elektra",
		tags: ["auth:sophocles", "genre:tragedy", "lang:greek", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2023-03-15_caesar:_on_the_gallic_war",
		title: "caesar: on the gallic war",
		tags: ["auth:caesar", "genre:misc", "lang:latin", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2023-02-14_short_talk_on_Vulcans",
		title: "short talk on Vulcans",
		tags: ["auth:sappho", "topic:trek", "type:essay"],
		projects: []
	},
	{
		path: "2023-02-14_sappho:_fragments",
		title: "sappho: fragments",
		tags: ["auth:sappho", "genre:lyric", "lang:greek", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2023-01-05_ovid:_heroides",
		title: "ovid: heroides",
		tags: ["auth:ovid", "genre:elegy", "lang:latin", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2022-12-25_seneca:_apocolocyntosis",
		title: "seneca: apocolocyntosis",
		tags: ["auth:seneca", "genre:misc", "lang:latin", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2022-11-29_cicero:_against_catiline",
		title: "cicero: against catiline",
		tags: ["auth:cicero", "genre:oratory", "lang:latin", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2022-11-04_tell_stories_of_freedom",
		title: "tell stories of freedom",
		tags: ["type:rec", "topic:fanfiction", "topic:trek"],
		projects: []
	},
	{
		path: "2022-10-20_vergil:_aeneid",
		title: "vergil: aeneid",
		tags: ["auth:vergil", "genre:epic", "lang:latin", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2022-09-12_a_terrible_reading_of_heroides_14",
		title: "a terrible reading of heroides 14",
		tags: ["auth:ovid", "type:response", "lang:latin"],
		projects: []
	},
	{
		path: "2022-08-28_aeschylus:_agamemnon",
		title: "aeschylus: agamemnon",
		tags: ["auth:aeschylus", "genre:tragedy", "lang:greek", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2022-08-07_the_horniness_of_heroides_iv",
		title: "the horniness of heroides iv",
		tags: ["auth:ovid", "genre:elegy", "lang:latin", "type:commentary"],
		projects: []
	},
	{
		path: "2022-07-30_a_memory_called_empire",
		title: "a memory called empire",
		tags: ["topic:reception", "genre:sci-fi", "type:response"],
		projects: []
	},
	{
		path: "2022-07-09_kirk's_call",
		title: "kirk's call",
		tags: ["topic:trek"],
		projects: []
	},
	{
		path: "2022-07-06_homer: iliad",
		title: "homer: iliad",
		tags: ["auth:homer", "genre:epic", "lang:greek", "type:essay"],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2022-07-06_obnoxious_ovid",
		title: "obnoxious ovid",
		tags: ["auth:ovid"],
		projects: []
	},
	{
		path: "2022-07-04_classical literature for fandom purposes",
		title: "classical literature for fandom purposes",
		tags: [],
		projects: ["classical literature for fandom purposes"]
	},
	{
		path: "2022-06-26_sophocles_ftw",
		title: "sophocles ftw",
		tags: ["auth:sophocles", "auth:aeschylus", "lang:greek"],
		projects: []
	},
	{
		path: "2022-06-09_textual_transmission",
		title: "textual transmission",
		tags: ["auth:aeschylus", "topic:history"],
		projects: []
	},
	{
		path: "2022-06-03_elektra_denied_speech",
		title: "elektra denied speech",
		tags: ["auth:sophocles", "lang:greek"],
		projects: []
	},
	{
		path: "2022-06-03_elektra_and_clytemnestra",
		title: "elektra and clytemnestra",
		tags: ["auth:sophocles", "lang:greek"],
		projects: []
	},
	{
		path: "2022-06-03_elektra_one-liners",
		title: "elektra one-liners",
		tags: ["auth:sophocles", "lang:greek"],
		projects: []
	},
	{
		path: "2022-06-02_elektra's_power_of_speech",
		title: "elektra's power of speech",
		tags: ["auth:sophocles", "lang:greek"],
		projects: []
	},
	{
		path: "2022-06-02_my_favorite_thing(s)_about_sophocles",
		title: "my favorite thing(s) about sophocles",
		tags: ["auth:sophocles", "lang:greek"],
		projects: []
	},
	{
		path: "2022-05-24_clytemnestra_and_the_truth",
		title: "clytemnestra and the truth",
		tags: ["auth:aeschylus", "lang:greek"],
		projects: []
	},
	{
		path: "2022-05-24_the_blood_on_the_earth_speech",
		title: "the blood on the earth speech",
		tags: ["auth:aeschylus", "lang:greek"],
		projects: []
	},
	{
		path: "2022-05-23_roman_legal_terms",
		title: "roman legal terms",
		tags: ["lang:latin", "topic:law"],
		projects: []
	},
	{
		path: "2022-05-21_slavery_in_roman_law",
		title: "slavery in roman law",
		tags: ["topic:law", "topic:history"],
		projects: []
	},
	{
		path: "2022-05-19_proculians_vs._sabinians",
		title: "proculians vs. sabinians",
		tags: ["topic:history"],
		projects: []
	},
	{
		path: "2022-05-17_aequus",
		title: "aequus",
		tags: ["lang:latin"],
		projects: []
	},
	{
		path: "2022-05-17_mothers_in_the_house_of_atreus",
		title: "mothers in the house of atreus",
		tags: ["topic:myth", "lang:greek"],
		projects: []
	},
	{
		path: "2022-05-15_heroides_1.3",
		title: "heroides 1.3",
		tags: ["auth:ovid", "genre:elegy", "type:commentary", "lang:latin", "type:response"],
		projects: []
	},
	{
		path: "2022-04-25_horror_in_ovid",
		title: "horror in ovid",
		tags: ["auth:ovid", "lang:latin"],
		projects: []
	},
	{
		path: "2022-04-23_dukat's_de_occupatione_baiorana",
		title: "dukat's de occupatione baiorana",
		tags: ["auth:caesar", "topic:trek"],
		projects: ["trek and the classics"]
	},
	{
		path: "2022-04-23_her._12.31-36:_a_mini_commentary",
		title: "her. 12.31-36: a mini commentary",
		tags: ["auth:ovid", "type:commentary", "lang:latin"],
		projects: []
	},
	{
		path: "2022-04-20_garak_and_the_aeneid",
		title: "garak and the aeneid",
		tags: ["topic:reception", "topic:trek", "auth:vergil", "lang:latin"],
		projects: ["trek and the classics"]
	},
	{
		path: "2022-03-28_in_appreciation_of_the_heroides",
		title: "in appreciation of the heroides",
		tags: ["auth:ovid", "type:response", "lang:latin"],
		projects: []
	},
	{
		path: "2022-03-28_trek_and_my_parents",
		title: "trek and my parents",
		tags: ["topic:trek"],
		projects: []
	},
	{
		path: "2022-03-15_vulcans_vs._cybermen",
		title: "vulcans vs. cybermen",
		tags: ["topic:trek", "topic:doctor who"],
		projects: []
	},
	{
		path: "2022-03-12_on_ovid",
		title: "on ovid",
		tags: ["auth:ovid", "type:rec", "topic:reception"],
		projects: []
	},
	{
		path: "2022-03-08_greek_myths:_a_new_retelling_2",
		title: "greek myths: a new retelling 2",
		tags: ["type:response", "auth:ovid", "topic:myth", "topic:reception"],
		projects: []
	},
	{
		path: "2022-02-28_not_to_me",
		title: "not to me",
		tags: ["auth:euripides", "lang:greek"],
		projects: []
	},
	{
		path: "2022-02-17_pegasus",
		title: "pegasus",
		tags: ["type:response"],
		projects: []
	},
	{
		path: "2022-02-13_classical_reception_projects_i'd_do_if_star_trek_were_real",
		title: "classical reception projects i'd do if star trek were real",
		tags: ["topic:trek", "topic:reception", "auth:homer", "auth:sappho", "auth:carson, anne", "auth:vergil", "lang:latin", "lang:greek"],
		projects: ["trek and the classics"]
	},
	{
		path: "2022-02-12_raeburn's_metamorphoses",
		title: "raeburn's metamorphoses",
		tags: ["auth:ovid", "type:response", "lang:latin"],
		projects: []
	},
	{
		path: "2022-01-29_threshold_day",
		title: "threshold day",
		tags: ["topic:trek"],
		projects: []
	},
	{
		path: "2022-01-23_the_frogs_in_plato's_stepchildren",
		title: "the frogs in plato's stepchildren",
		tags: ["topic:trek", "auth:aristophanes", "topic:reception", "lang:greek"],
		projects: ["trek and the classics"]
	},
	{
		path: "2022-01-17_procne_and_philomela",
		title: "procne and philomela",
		tags: ["auth:ovid", "lang:latin"],
		projects: []
	},
	{
		path: "2022-01-16_classical_terminology",
		title: "classical terminology",
		tags: ["topic:queerness", "type:response"],
		projects: []
	},
	{
		path: "2022-01-14_greek_myths_a_new_retelling",
		title: "greek myths: a new retelling",
		tags: ["type:response", "topic:myth", "auth:ovid", "topic:reception"],
		projects: []
	},
	{
		path: "2022-01-08_the_saint_in_paradise_speech",
		title: "the saint in paradise speech",
		tags: ["topic:trek"],
		projects: []
	},
	{
		path: "2021-12-22_fic_and_discomfort",
		title: "fic and discomfort",
		tags: ["topic:fanfiction"],
		projects: []
	},
	{
		path: "2021-12-06_perfect_vs._problematic",
		title: "perfect vs. problematic",
		tags: ["auth:ovid"],
		projects: []
	}
];

for (let i in postsArray) postsArray[i].path = "posts/" + postsArray[i].path + ".html";

/* ------------------
	2.2. MESSAGES
------------------ */

const messagesArray = [
	"...hum a little, Mr Bones.", // john berryman, dream song 76
	"I see him there on a night like this but cool...", // anne carson, on ovid
	"...the way/that desire can make anything into a god.", //mark doty, the death of antinous
	"Midnight shakes the memory/As a madman shakes a dead geranium.", // t. s. eliot, rhapsody on a windy night
	"Something there is that doesn't love a wall...", // robert frost, mending wall
	"What peaches and what penumbras!", // allen ginsburg, a supermarket in california
	"We speak only/to the dead, someone tells me...", // elisa gonzales, after my brother's death
	"Innocence is no earthly weapon.", // geoffrey hill, ovid in the third reich
	"Διὸς δ’ ἐτελείετο βουλή.", // homer, il. 1.5
	"Glory be to God for dappled things...", // gerard manley hopkins, pied beauty
	"Gods make their own importance.", // patrick kavanaugh, epic
	"Illa fuit mentis prima ruina meae.", // ov. her. 12.32
	"Abstulerant oculi lumina nostra tui.", // ov. her. 12.36
	"Non est, quam piget esse, pia.", // ov. her. 14.14
	"Ars adeo latet arte sua.", // ov. met. 10.252
	"Omnia mutantur, nihil interit.", // ov. met. 15.165
	"μήτε μοι μέλι μήτε μέλισσα", // sappho, fr. 146
	"Ὦ φάος ἁγνὸν/καὶ γῆς ἰσόμοιρ' ἀήρ..." // soph. el. 86–86
];



/* ================================
	3. CREATING INSERTABLE HTML
================================ */

function formatPostLink(i, postsArray_i) { // take an index and an array of posts (which may be postsArray or a subset) and return an HTML-tagged link for that indexed post
	let linkText = "";
	const postTitle_i = postsArray_i[i].title;

	linkText += '<li><a href="' + relativePath + '/' + postsArray_i[i].path + '">';

	const monthNums2Names = {
		"01": "January",
		"02": "February",
		"03": "March",
		"04": "April",
		"05": "May",
		"06": "June",
		"07": "July",
		"08": "August",
		"09": "September",
		"10": "October",
		"11": "November",
		"12": "December"
	};

	linkText += '<span class="post-title">' + postTitle_i + "</span>";
	if (postDateFormat.test (postsArray_i[i].path.slice(6,17))) linkText += " | " + monthNums2Names[postsArray_i[i].path.slice(11,13)] + " " + postsArray_i[i].path.slice(14,16) + ", " + postsArray_i[i].path.slice(6,10) + '</a></li>';
	return linkText;
}

function buildPostIndex(tagType, emptyMessage) { // take a json object of posts pre-sorted by tags (or another parameter) and output HTML for a list of tags, each of which has a sub-lists of posts
	let listText = "";

	for (let i = 0; i < postsArray.length; i++) { // set up an object of all posts by tag
		for (let j = 0; j < postsArray[i][tagType].length; j++) {
			if (typeof allTags[postsArray[i][tagType][j]] == 'undefined') allTags[postsArray[i][tagType][j]] = [];

			allTags[postsArray[i][tagType][j]].push({path: postsArray[i].path, title: postsArray[i].title});
		}
	}
	const allTagNames = Object.keys(allTags).sort((a, b) => a.localeCompare(b, undefined, {sensitivity: 'base'}));

	if (allTagNames.length > 0) {
		for (let i = 0; i < allTagNames.length; i++) {
			let tagName = allTagNames[i];
			listText += '<li><details id="--' + tagName.replace(/ /g,"-") + '"><summary>' + tagName + '</summary><ul class="post-list">';
			for (let j = 0; j < allTags[tagName].length; j++) listText += formatPostLink(j, allTags[tagName]);
			listText += '</ul></details></li>';
		}
	} else listText += '<li>' + emptyMessage + '</li>';

	return listText;
}

function buildProjIndex(projectType, emptyMessage) { // take a json object of posts pre-sorted by projects (or another parameter) and output HTML for a list of projects, each of which has a sub-lists of posts
	let listText = "";

	for (let i = 0; i < postsArray.length; i++) { // set up an object of all posts by project
		for (let j = 0; j < postsArray[i][projectType].length; j++) {
			if (typeof allProjects[postsArray[i][projectType][j]] == 'undefined') allProjects[postsArray[i][projectType][j]] = [];

			allProjects[postsArray[i][projectType][j]].push({path: postsArray[i].path, title: postsArray[i].title});
		}
	}
	const allProjectNames = Object.keys(allProjects).sort((a, b) => a.localeCompare(b, undefined, {sensitivity: 'base'}));

	if (allProjectNames.length > 0) {
		for (let i = 0; i < allProjectNames.length; i++) {
			let projectName = allProjectNames[i];
			listText += '<li><details id="--' + projectName.replace(/ /g,"-") + '"><summary>' + projectName + '</summary><ul class="post-list">';
			for (let j = 0; j < allProjects[projectName].length; j++) listText += formatPostLink(j, allProjects[projectName]);
			listText += '</ul></details></li>';
		}
	} else listText += '<li>' + emptyMessage + '</li>';

	return listText;
}

const url = window.location.pathname;

// final array of blog items (outer key: variable name, inner values: HTML element id/class and inner HTML)
const blog = {
	header: {id: "header", HTML: ""},
	niceDate: {id: "post-date", HTML: ""},
	postMeta: {id: "post-meta", HTML: ""},
	postNav: {id: "post-nav", HTML: ""},
	footer: {id: "footer", HTML: ""},
	archivePostList: {id: "archive-post-list", HTML: ""},
	recentPostList: {id: "recent-post-list", HTML: ""},
	tagIndex: {id: "tag-index", HTML: ""},
	projectIndex: {id: "project-index", HTML: ""}
};

// if reader is in posts, put relative path up by one directory
let relativePath = (url.includes("posts/")) ? ".." : ".";

if (url.includes("projects/")) {
	relativePath = (url.includes("projects/")) ? ".." : ".";
}
	
const postDateFormat = /\d{4}\-\d{2}\-\d{2}\_/;

// write the header HTML

blog.header.HTML += '<nav id="main-nav"><ul>' +
'<li id="title"><a href="' + relativePath + '/">' + blogName + '</a></li>' +
'<li><a href="' + relativePath + '/about.html">about</a></li>' +
'<li><a href="' + relativePath + '/tags.html">tags</a></li>' +
'<li><a href="' + relativePath + '/projects.html">projects</a></li>' +
'<li><a href="' + relativePath + '/archive.html">archive</a></li>'
'</ul></nav>';

if (headerMessageOn && messagesArray.length > 0) {
	let randMessage = messagesArray[Math.floor(Math.random() * messagesArray.length)];
	blog.header.HTML += '<hr/><p id="header-message"><svg viewBox="0 0 22 22"><circle cx="11" cy="11" r="8"/></svg> ' + randMessage + '</p>';
}

// write the footer HTML
blog.footer.HTML += '<hr/><p>find me elsewhere: ' + footerLinks.join(" | ");
blog.footer.HTML += '<a id="return-link" href="#container" rel="return">\u2191 back to top</a></p>';

// To do the following stuff, we want to know where we are in the post array (if we're currently on a post page).
let currentIndex = -1;
let currentFilename = url.substring(url.lastIndexOf('posts/'));
// Depending on the web server settings (Or something?), the browser url may or may not have ".html" at the end. If not, we must add it back in to match the posts array. (12-19-2022 fix)
if ( ! currentFilename.endsWith(".html") ) {
		currentFilename += ".html";
}
let i;
for (let i = 0; i < postsArray.length; i++) {
	if (postsArray[i].path === currentFilename) {
		currentIndex = i;
		break;
	}
}

/* -------------------
	3.1. POST PAGE
------------------- */

// get the current post title, date, and tags (if on a post page), and the post nav links
const tagList = [];
const projectList = []

if (currentIndex > -1) {
	// generate more-readable date
	const monthNums2Names = {
		"01": "January",
		"02": "February",
		"03": "March",
		"04": "April",
		"05": "May",
		"06": "June",
		"07": "July",
		"08": "August",
		"09": "September",
		"10": "October",
		"11": "November",
		"12": "December"
	};

	if (postDateFormat.test (postsArray[currentIndex].path.slice(6,17))) {
		blog.niceDate.HTML += monthNums2Names[postsArray[currentIndex].path.slice(11,13)] + " " + postsArray[currentIndex].path.slice(14,16) + ", " + postsArray[currentIndex].path.slice(6,10)

	}

	document.getElementById("post-date").setAttribute("datetime",postsArray[currentIndex].path.slice(6,16));

	// generate post tags HTML
	if (postsArray[currentIndex].tags.length > 0) {
		postsArray[currentIndex].tags.sort((a, b) => a.localeCompare(b, undefined, {sensitivity: 'base'}));
		for (let i = 0; i < postsArray[currentIndex].tags.length; i++) {
	  		let tagName = postsArray[currentIndex].tags[i];
			tagList[i] = '<li><a href="' + relativePath + '/tags.html#--' + tagName.replace(/\s/g,"-") + '" rel="tag">' + tagName + '</a></li>';
		}
	} else {
		tagList[0] = "none";
	}

	blog.postMeta.HTML += '<dt>Tags</dt><dd id="tag-list">' + tagList.join("") + '</dd>';

	// generate post projects HTML
	if (postsArray[currentIndex].projects.length > 0) {
		postsArray[currentIndex].projects.sort((a, b) => a.localeCompare(b, undefined, {sensitivity: 'base'}));
		for (let i = 0; i < postsArray[currentIndex].projects.length; i++) {
	  		let projectName = postsArray[currentIndex].projects[i];
			projectList[i] = '<li><a href="' + relativePath + '/projects.html#--' + projectName.replace(/\s/g,"-") + '" rel="project">' + projectName + '</a></li>';
		}
	} else {
		projectList[0] = "none";
	}

	blog.postMeta.HTML += '<dt>Projects</dt><dd id="project-list">' + projectList.join("") + '</dd>';

	// generate post nav HTML
	let prevPost,
	nextPost;

	// if before latest post:
	if (currentIndex > 0) {
		prevPost = postsArray[currentIndex - 1];
		blog.postNav.HTML += '<div><a href="' + relativePath + '/' + prevPost.path + '" rel="next">\u2190 Next Post</a><p>' + prevPost.title + '</p></div>';
	} else blog.postNav.HTML += '<div>Latest post!</div>';

	// if after earliest post:
	if (0 <= currentIndex && currentIndex < postsArray.length - 1) {
		nextPost = postsArray[currentIndex + 1];
		blog.postNav.HTML += '<div><a href="'+ relativePath + '/' + nextPost.path + '" rel="prev">Previous Post \u2192</a><p>' + nextPost.title + '</p></div>';
	} else blog.postNav.HTML += '<div>First post!</div>';
}

/* ----------------------
	3.2. ARCHIVE LIST
---------------------- */

// generate the Post List HTML
if (document.getElementById(blog.archivePostList.id)) {
	for (let i = 0; i < postsArray.length; i++) {
		blog.archivePostList.HTML += formatPostLink(i, postsArray);
	}
}

/* --------------------------
	3.3. RECENT POST LIST
-------------------------- */

// generate the Recent Post List HTML
if (document.getElementById(blog.recentPostList.id)) {
	const numberOfRecentPosts = Math.min(recentPostsCutoff, postsArray.length);
	for (let i = 0; i < numberOfRecentPosts; i++) {
		blog.recentPostList.HTML += formatPostLink(i, postsArray);
	}

	// if there are more posts than the cutoff, end the list with a link to the Archive
	if (postsArray.length > recentPostsCutoff) {
		blog.recentPostList.HTML += '<li id="more-posts"><a href=' + relativePath + '/archive.html>\u2192 more posts</a></li>';
	}
}

/* -------------------
	3.4. TAG AND PROJECT INDEX
------------------- */

// if reader is on the tags page, generate the Tag Index HTML
const allTags = {};


if (document.getElementById(blog.tagIndex.id)) blog.tagIndex.HTML = buildPostIndex("tags", 'This blog currently uses no tags!');

// if reader is on the projects page, generate the Project Index HTML
const allProjects = {};


if (document.getElementById(blog.projectIndex.id)) blog.projectIndex.HTML = buildPostIndex("projects", 'This blog currently has no projects!');



/* =================================
	4. INSERTING HTML INTO PAGES
================================= */

// for each blog item, if its element is in the file, insert its HTML
for (let i in blog) {
	const element = document.getElementById(blog[i].id);
	if (element) element.innerHTML = blog[i].HTML;
	else {
		const elements = document.getElementsByClassName(blog[i].id);
		if (elements.length > 0) {
			for (let j in elements) {
				elements[j].innerHTML = blog[i].HTML;
			}
		}
	}
}

// if on an index page, open the selected item's sub-list (if any) using its id
if (document.querySelector(".index") && window.location.hash) document.getElementById(window.location.hash.slice(1))?.setAttribute("open", "");