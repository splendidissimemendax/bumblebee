# Bumblebee

A JS-based framework for building a site, based on the [Zonelots framework](https://codeberg.org/01bbl/Zonelots) (itself based off [Zonelets](https://zonelets.net/), with added tagging functionality). This is primarily a personal project (it's what I use on my Neocities site) and is thus fairly idiosyncratic, but I wanted to make it available in case anyone else might find it useful.

## differences

### from Zonelets (via Zonelots)

1. **Tags**: You can tag posts. There's a tag page where you can see all tags and the posts tagged with them. This is run through the JS script, so you only have to update them in one place.

2. **Header messages**: The script will show a random message from a list. This can be turned on and off.

3. **Post navigation**: Includes post titles in the page navigation links.

### from Zonelots

1. **Update**: The most important feature is that I've fixed the bit of the code that was broken, based on a solution worked out by [strflr](https://strflr.neocities.org/blog/posts/2024-03-24-Zonelots-Fix).

2. **Automation**: I've written some Python code that makes use of the Neocities CLI to automate things like pushing updates. Basically, you only have to use the Neocities dashboard to delete or rename files. And even if you're not hosting your site on Neocities, you can use the functions that create posts and update the post index based on user inputs.

3. **Projects**: Based on the framework of tagging. I personally have a bunch of tags and having a separate system for projects (rather than just using tags) helps me keep things organized.

4. **Post navigation**: I removed the nav links at the top of the page.

4. **Themes**: I've written a handful of site themes that utilize the same JS script.

5. **Trekify**: I've made some adjustments (which can be turned on/off) to the JS for use in my Star Trek site theme.

## Set up

1. Edit anything in double curly brackets in the .html files (you can use the find and replace function in functions.py to replace things across multiple files).

2. Edit the information in section 1 of script.js (the blog name, whether you want header messages on, etc.).

3. Replace the favicon. If not using a file called favicon.svg, remember to change the file name in your .html pages.

3. Pick a theme and copy/paste it into style.css.

4. Delete the example posts and their data, as well as any unused themes.

5. Add your API key and the path to the *site file to the functions.py.

6. Push site to Neocities with the script, or upload wherever you choose.

## Adding a post

1. Run functions.py and select the function you want to perform.

2. In the terminal, input the requested information in the requested form (e.g. dates are yyyy-mm-dd).

3. If you've backdated a post, you'll have to move that entry in the post index array by hand or posts won't be in date order. Otherwise, you're done.