from os import walk
from os.path import join, splitext
from datetime import date
from subprocess import run
from re import sub

api = "" # insert api here
location = "" # insert path to *site folder here

# find/replace across files
def fix(filetype, search, replace, no = 9999):

	onlyfiles = []
	
	for root, dirs, files in walk("./*site", topdown=False):
		for name in files:
			onlyfiles.append(join(root, name))

	type = "." + filetype.lower()
	list = []

	for f in onlyfiles:
		ext = splitext(f)[-1].lower()

		if ext == type:
			with open(f, "r") as file:
				data = file.read()
				data = sub(search, replace, data, no)
			
			with open(f, "w") as file:
				file.write(data)
			
			list.append(f)

	print(list)

# update post index
def updateindex(path, title, tags, projects):
	replacetext = '\n	{\n		path: "' + path + '",\n		title: "' + title + '",\n		tags: [' + tags + '],\n		projects: [' + projects + ']\n	},'

	with open("./*site/script.js", "r") as file:
		data = file.read()
		data = data.replace("const postsArray = [", "const postsArray = [" + replacetext)

	with open("./*site/script.js", "w") as file:
		file.write(data)

	print("File updated.")

# create a new post
def newpost(title, description, dt = str(date.today())):
	file = title.replace(" ", "_")

	path = "./*site/posts/" + dt + "_" + file + ".html"

	with open("./*site/posts/template.html", "r") as f:
		data = f.read()
		data = data.replace("{{YOUR BLOG POST TITLE HERE}}", title)
		data = data.replace("{{YOUR BLOG POST DESCRIPTION HERE}}", description)

	with open(path, "w") as f:
		f.write(data)

# update neocities site
def push():
	result = run(["NEOCITIES_API_KEY=" + api + " neocities push " + location], shell=True, capture_output=True, text=True, encoding="utf-8")

	print(result.stdout)

# clean a post
def clean(filename, dt):
	file = filename.replace(" ", "_")

	path = "./*site/posts/" + dt + "_" + file + ".html"

	with open(path, "r") as f:
		data = f.read()

		# replace i with em
		data = data.replace("<i>", "<em>")
		data = data.replace("</i>", "</em>")

		# replace b with strong
		data = data.replace("<b>", "<strong>")
		data = data.replace("</b>", "</strong>")

		# clear useless stuff
		data = data.replace(' class="npf_indented\"', "")
		data = data.replace(' target="_blank"', "")
		data = data.replace(' rel=\"nofollow\"', "")
		data = data.replace('https://href.li/?', '')

	with open(path, "w") as f:
		f.write(data)




# INPUTS

# fix(filetype, search, replace): find/replace across files
# updateindex(path, title, tags): updates post index
# newpost(title): creates a new post
# push(): updates neocities site

action1 = input("Find/replace (1), push changes (2), or edit posts (3): ")

if int(action1) == 1:
	filetype = input("file type: ")
	searchtext = input("find: ")
	replacetext = input("replace with: ")

	fix(filetype, searchtext, replacetext)

	print("\nAll instances of " + searchtext + " in " + filetype + " files have been replaced with " + replacetext + ".\n")

elif int(action1) == 2:
	push()

	print("Changes pushed!\n")

elif int(action1) == 3:
	action2 = input("Create a new post (1) or a backdated post (2), update the post index (3), create a new file (4), or clean a post (5): ")

	if int(action2) == 1:
		posttitle = input("post title: ")
		descr = input("post description: ")
		posttags = input("tags (in double quotes, comma separated): ")
		postprojects = input("projects (in double quotes, comma separated): ")
		today = str(date.today())

		filename = posttitle.replace(" ", "_")
		path = today + "_" + filename

		newpost(posttitle, descr)
		updateindex(path, posttitle, posttags, postprojects)

		print("\nA new post \"" + posttitle + "\" with the description \"" + descr + "\" and the tags [" + posttags + "] in the project " + postprojects + " has been created.\n")

	elif int(action2) == 2:
		posttitle = input("post title: ")
		descr = input("post description: ")
		posttags = input("tags (in double quotes, comma separated): ")
		postprojects = input("projects (in double quotes, comma separated): ")
		dt = input("date (yyyy-mm-dd): ")

		today = str(date.today())

		filename = posttitle.replace(" ", "_")
		path = dt + "_" + filename

		newpost(posttitle, descr, dt)
		updateindex(path, posttitle, posttags, postprojects)

		fix("js", today, dt, 1)

		print("\nA new post \"" + posttitle + "\" with the description \"" + descr + "\" and the tags [" + posttags + "] in the project " + postprojects + " dated " + dt + " has been created.\n")

	elif int(action2) == 3:

		dt = input("date (yyyy-mm-dd): ")
		posttitle = input("post title: ")
		posttags = input("tags (in double quotes, comma separated): ")
		postprojects = input("projects (in double quotes, comma separated): ")

		filename = dt + "_" + posttitle.replace(" ", "_")

		updateindex(filename, posttitle, posttags, postprojects)

		print("\nThe post \"" + posttitle + "\" (" + filename + ") with the tags [" + posttags + "] in the project " + postprojects + " has been added to the index.\n")

	elif int(action2) == 4:
		posttitle = input("post title: ")
		descr = input("post date: ")

		newpost(posttitle, descr)

		print("\nA new post \"" + posttitle + "\" with the description \"" + descr + "\" has been created.\n")

	elif int(action2) == 5:
		posttitle = input("post title: ")
		date = input("post date: ")

		clean(posttitle, date)

		print("\n\"" + posttitle + "\" has been cleaned.\n")

	else:
		print("\nThat wasn't an option. Try again.\n")

else:
	print("\nThat wasn't an option. Try again.\n")