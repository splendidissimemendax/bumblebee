import re

file = "html/working.html"

html = open(file, "r", encoding="utf-8")

filename = re.sub("\.html", "", file)
html_clean = open(filename + "_clean.html", "w+", encoding="utf-8")

for line in html:
    line = re.sub(" rel=\"nofollow\"", "", line)
    line = re.sub("\"n", "\"fn", line)
    line = re.sub("#n", "#fn", line)
    line = re.sub("n\d+.", "n", line)
    line = re.sub("h4", "h2", line)
    line = re.sub("h5", "h3", line)
    line = re.sub("h6", "h4", line)
    line = re.sub(" title=\"", " data-toggle=\"tooltip\" title=\"", line)
    line = re.sub(" class=\"\"", "", line)
    html_clean.write(line)

html_clean.close()
html.close()