import re

file = "html/working.html"

html = open(file, "r", encoding="utf-8")

filename = re.sub("\.html", "", file)
html_clean = open(filename + "_clean.html", "w+", encoding="utf-8")

x = 0

for line in html:
	# if line == "\s*<div class=\"page-body\">" or line == "\s*</article>":
	# 	x+=1
	# if x == 1:
	line = re.sub(" id=\".*\"", "", line)
	line = re.sub(" class=\"\"", "", line)
	line = re.sub("style=\".*\"", "", line)
	html_clean.write(line)

html_clean.close()
html.close()